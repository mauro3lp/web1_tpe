# WEB 1 - Trabajo Practico Especial

### Integrantes:

- Mauro Perez
- Martin Cappi

### Cosas a corregir

- "Uso de let"
- En las clases de css, cambiar camelCase por kebab-case
- A los links y rutas quitarle el ./ ej: <a href="index.html"></a>
- Para los espacios y dimensiones de ancho, usar %

### Para la entrega 2

- La tabla con %
- Tabla dinamica: arranca vacia (puede estar el thead)
  - Agregar x3: pueden ser 3 veces el mismo input, 3 random o "3 valores" (triplicar los input)